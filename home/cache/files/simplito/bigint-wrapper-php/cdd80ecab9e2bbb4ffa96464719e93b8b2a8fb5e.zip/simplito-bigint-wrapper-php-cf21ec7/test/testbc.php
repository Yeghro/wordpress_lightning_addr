<?php

define('S_MATH_BIGINTEGER_MODE', "bcmath");

require(__DIR__ . "/../lib/BigInteger.php");
require(__DIR__ . "/test.php");